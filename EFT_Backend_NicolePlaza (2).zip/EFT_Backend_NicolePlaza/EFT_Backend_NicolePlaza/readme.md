# Banco XYZ — Backend de Microservicios

**Asignatura:** Desarrollo Backend III (PBY2203) — Evaluación Final Transversal
**Caso:** Modernización del sistema legacy del Banco XYZ hacia una arquitectura de microservicios en la nube.

Este repositorio contiene el código fuente completo del proyecto. Reemplaza el
antiguo sistema monolítico (COBOL + Shell sobre mainframe) por una arquitectura
moderna basada en **Spring Boot 3 / Spring Cloud 2023**, con procesos batch
migrados a **Spring Batch**, el patrón **Backend for Frontend (BFF)** por canal,
microservicios resilientes y seguros, y mensajería asíncrona con **Apache Kafka**.

---

## 1. Procesos clave de la migración

El proyecto implementa los cinco procesos críticos de la migración:

1. **Migración de procesos batch** a Spring Batch (`batch-service`).
2. **División del monolito en microservicios** (`cuentas-service`, `pagos-service`, `clientes-service`).
3. **Patrón Backend for Frontend (BFF)** para tres canales (`bff-web`, `bff-movil`, `bff-cajero`).
4. **Seguridad distribuida** con OAuth2 / Spring Security (`auth-server` + resource servers).
5. **Mensajería asíncrona** con Apache Kafka (productor en `pagos-service`, consumidor en `cuentas-service`).

---

## 2. Arquitectura

```
                           ┌──────────────────┐
        Clientes  ───────▶ │   API Gateway     │  (8080, valida JWT)
   (web / móvil / cajero)  └─────────┬────────┘
                                     │  lb:// (Eureka)
            ┌────────────────────────┼────────────────────────┐
            ▼                        ▼                         ▼
       ┌─────────┐             ┌──────────┐              ┌───────────┐
       │ bff-web │             │ bff-movil│              │ bff-cajero│
       │  (8091) │             │  (8092)  │              │   (8093)  │
       └────┬────┘             └────┬─────┘              └─────┬─────┘
            │  Feign + Resilience4j (circuit breaker + fallback)      │
            └───────────────┬───────────────┬───────────────────────┘
                            ▼               ▼                ▼
                   ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
                   │cuentas-service│ │pagos-service │ │clientes-svc  │
                   │    (8081)     │ │   (8082)     │ │   (8083)     │
                   └──────┬────────┘ └──────┬───────┘ └──────────────┘
                          │   Kafka         │
                          │◀──transacciones-completadas──┘
                          │   (consumidor)   (productor) ──▶ alertas-seguridad

   Infraestructura transversal:
   • config-server (8888)  — configuración centralizada (Spring Cloud Config)
   • eureka-server (8761)  — descubrimiento de servicios y balanceo de carga
   • auth-server   (9000)  — OAuth2 Authorization Server (emite JWT por canal)
   • batch-service (8084)  — procesos Spring Batch sobre los datos legacy
```

Diagramas de arquitectura, de componentes y de casos de uso en detalle: ver el
**Informe Técnico** (`Informe_Tecnico_PBY2203_EFT.pdf`).

---

## 3. Stack tecnológico

| Área | Tecnología |
|------|------------|
| Lenguaje / runtime | Java 17 |
| Framework | Spring Boot 3.2.5 |
| Nube / microservicios | Spring Cloud 2023.0.1 |
| Batch | Spring Batch 5 |
| Descubrimiento | Netflix Eureka |
| Config centralizada | Spring Cloud Config |
| Gateway | Spring Cloud Gateway |
| Seguridad | OAuth2 (Spring Authorization Server) + Resource Servers (JWT) |
| Resiliencia | Resilience4j (circuit breaker, retry, fallback) |
| Mensajería | Apache Kafka (Spring Kafka) |
| Comunicación interna | OpenFeign + balanceo por Eureka |
| Persistencia | Spring Data JPA — H2 (local) / PostgreSQL (nube) |
| Contenedores | Docker + Docker Compose |
| Build | Maven (proyecto multi-módulo) |

---

## 4. Estructura del repositorio

```
banco-xyz-backend/
├── pom.xml                  # POM padre (reactor multi-módulo)
├── docker-compose.yml       # Orquestación completa
├── Dockerfile.module        # Dockerfile parametrizable alternativo
├── config-repo/             # Configuración centralizada servida por Config Server
├── config-server/           # Spring Cloud Config Server (8888)
├── eureka-server/           # Service Discovery (8761)
├── api-gateway/             # Puerta de entrada + balanceo + seguridad de borde (8080)
├── auth-server/             # OAuth2 Authorization Server (9000)
├── cuentas-service/         # Microservicio Gestión de Cuentas (8081)
├── pagos-service/           # Microservicio Procesamiento de Pagos (8082)
├── clientes-service/        # Microservicio Gestión de Clientes (8083)
├── bff-web/                 # BFF canal web (8091)
├── bff-movil/               # BFF canal móvil (8092)
├── bff-cajero/              # BFF canal cajeros (8093)
├── batch-service/           # Procesos Spring Batch (8084)
│   └── src/main/resources/data/   # Datos legacy de muestra (CSV)
├── readme.md                # Este archivo
├── instrucciones.md         # Cómo ejecutar y probar cada componente
└── despliegue.md            # Despliegue en la nube (AWS) y escalabilidad
```

---

## 5. Parte 1 — Procesos batch (Spring Batch)

`batch-service` reescribe los tres procesos legacy, leyendo los CSV del
repositorio de datos (`KariVillagran/fin_legacy_data`):

| Job | Fuente | Descripción |
|-----|--------|-------------|
| `jobReporteTransaccionesDiarias` | `movimientos_financieros_diarios.csv` | Procesa transacciones del día y marca anomalías (monto ≤ 0, tipo no reconocido). |
| `jobCalculoInteresesMensuales` | `intereses_trimestrales.csv` | Aplica intereses por tipo de cuenta (ahorro/préstamo/hipoteca). |
| `jobEstadosCuentaAnuales` | `estados_financieros_anuales.csv` | Compila el histórico anual para auditorías. |

Características: steps *leer → procesar → escribir* en chunks de 100; **skip** de
registros inválidos (`RegistroInvalidoException`); **retry** ante fallos
temporales de BD (`TransientDataAccessException`); **paralelismo** multi-hilo en
el proceso de alto volumen; **reejecución automática** vía `RunIdIncrementer` y
scheduler ante fallos críticos.

---

## 6. Parte 2 — Patrón BFF

Cada canal expone su propio backend, con respuestas optimizadas y seguridad
específica:

| BFF | Optimización | Seguridad |
|-----|--------------|-----------|
| `bff-web` | Datos completos agregados (cliente + cuentas) en una sola llamada. | Cliente OAuth2 `web-client`, scopes amplios. |
| `bff-movil` | Carga útil mínima (saldo total, cuentas ligeras) + compresión GZIP. | Cliente `movil-client`, scopes reducidos. |
| `bff-cajero` | Solo operaciones críticas (saldo, retiro) con validación estricta. | Cliente `cajero-client`, token de vida corta (5 min). |

Los BFF son **independientes** entre sí, permitiendo desarrollo paralelo de los
equipos frontend y backend.

---

## 7. Parte 3 — Microservicios resilientes

- **cuentas-service**: apertura, cierre y mantenimiento de cuentas. Consume
  eventos Kafka para actualizar saldos.
- **pagos-service**: pagos, transferencias y depósitos. Llama a cuentas-service
  con **Resilience4j** (circuit breaker + retry + fallback) y publica eventos
  Kafka (`transacciones-completadas`, `alertas-seguridad`).
- **clientes-service**: información personal y perfiles de clientes.

Transversal: Spring Cloud Config, Eureka (descubrimiento y balanceo), OAuth2 con
Spring Security para proteger endpoints, y preparación para despliegue en la nube
con Docker y escalabilidad horizontal.
