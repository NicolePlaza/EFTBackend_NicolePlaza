package cl.bancoxyz.batch.controller;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Permite lanzar bajo demanda cada proceso batch. Protegido por OAuth2:
 * requiere un token con scope de operaciones (ver SecurityConfig).
 */
@RestController
@RequestMapping("/api/batch")
public class BatchJobController {

    private final JobLauncher jobLauncher;
    private final Job jobReporteTransaccionesDiarias;
    private final Job jobCalculoInteresesMensuales;
    private final Job jobEstadosCuentaAnuales;

    public BatchJobController(JobLauncher jobLauncher,
                              @Qualifier("jobReporteTransaccionesDiarias") Job jobDiarias,
                              @Qualifier("jobCalculoInteresesMensuales") Job jobIntereses,
                              @Qualifier("jobEstadosCuentaAnuales") Job jobAnuales) {
        this.jobLauncher = jobLauncher;
        this.jobReporteTransaccionesDiarias = jobDiarias;
        this.jobCalculoInteresesMensuales = jobIntereses;
        this.jobEstadosCuentaAnuales = jobAnuales;
    }

    @PostMapping("/transacciones-diarias")
    public Map<String, String> transaccionesDiarias() throws Exception {
        return ejecutar(jobReporteTransaccionesDiarias);
    }

    @PostMapping("/calculo-intereses")
    public Map<String, String> calculoIntereses() throws Exception {
        return ejecutar(jobCalculoInteresesMensuales);
    }

    @PostMapping("/estados-anuales")
    public Map<String, String> estadosAnuales() throws Exception {
        return ejecutar(jobEstadosCuentaAnuales);
    }

    private Map<String, String> ejecutar(Job job) throws Exception {
        JobParameters params = new JobParametersBuilder()
                .addLong("timestamp", System.currentTimeMillis())
                .toJobParameters();
        var exec = jobLauncher.run(job, params);
        return Map.of(
                "job", job.getName(),
                "executionId", String.valueOf(exec.getId()),
                "status", exec.getStatus().toString());
    }
}
