package cl.bancoxyz.batch.exception;

/**
 * Se lanza cuando un registro de entrada no cumple las reglas de validacion
 * (dato faltante, formato de fecha invalido, tipo desconocido, duplicado, etc.).
 * Spring Batch la trata como registro "skippable": lo omite, lo contabiliza y
 * continua el procesamiento sin abortar el job, preservando la integridad.
 */
public class RegistroInvalidoException extends RuntimeException {
    public RegistroInvalidoException(String mensaje) {
        super(mensaje);
    }
}
