package cl.bancoxyz.batch.mapper;

import cl.bancoxyz.batch.exception.RegistroInvalidoException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Parseo tolerante de fechas. Los archivos legacy mezclan formatos
 * (yyyy-MM-dd, yyyy/MM/dd, dd-MM-yyyy, dd/MM/yyyy). Se normalizan todos a
 * LocalDate; si ninguno aplica, el registro se considera invalido.
 */
public final class FechaUtil {

    private static final List<DateTimeFormatter> FORMATOS = List.of(
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy")
    );

    private FechaUtil() {}

    public static LocalDate parsear(String valor) {
        if (valor == null || valor.isBlank()) {
            throw new RegistroInvalidoException("Fecha vacia");
        }
        String limpio = valor.trim();
        for (DateTimeFormatter f : FORMATOS) {
            try {
                return LocalDate.parse(limpio, f);
            } catch (Exception ignore) {
                // probar siguiente formato
            }
        }
        throw new RegistroInvalidoException("Formato de fecha invalido: " + valor);
    }
}
