package cl.bancoxyz.batch.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.SkipListener;
import org.springframework.stereotype.Component;

/**
 * Registra cada item omitido durante el procesamiento, dejando trazabilidad
 * de los datos de baja calidad detectados en los archivos legacy.
 */
@Component
public class LoggingSkipListener implements SkipListener<Object, Object> {

    private static final Logger log = LoggerFactory.getLogger("BATCH-SKIP");

    @Override
    public void onSkipInRead(Throwable t) {
        log.warn("Omitido en lectura: {}", t.getMessage());
    }

    @Override
    public void onSkipInProcess(Object item, Throwable t) {
        log.warn("Omitido en proceso: {}", t.getMessage());
    }

    @Override
    public void onSkipInWrite(Object item, Throwable t) {
        log.warn("Omitido en escritura: {}", t.getMessage());
    }
}
