package cl.bancoxyz.batch.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.stereotype.Component;

/**
 * Listener de ciclo de vida del job: informa estado final y metricas de
 * lectura/escritura/omision para auditoria y mejora continua.
 */
@Component
public class JobCompletionListener implements JobExecutionListener {

    private static final Logger log = LoggerFactory.getLogger("BATCH-JOB");

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Iniciando job '{}'", jobExecution.getJobInstance().getJobName());
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("Job '{}' finalizo con estado {}",
                jobExecution.getJobInstance().getJobName(), jobExecution.getStatus());
        for (StepExecution se : jobExecution.getStepExecutions()) {
            log.info("  Step '{}': leidos={}, escritos={}, omitidos={}, commits={}",
                    se.getStepName(), se.getReadCount(), se.getWriteCount(),
                    se.getSkipCount(), se.getCommitCount());
        }
    }
}
