package cl.bancoxyz.batch.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Politica de finalizacion y reejecucion automatica.
 * Programa el reporte diario y, si una ejecucion termina en estado FAILED
 * (fallo critico), la relanza automaticamente una vez.
 */
@Component
public class BatchScheduler {

    private static final Logger log = LoggerFactory.getLogger(BatchScheduler.class);
    private static final int MAX_REINTENTOS = 1;

    private final JobLauncher jobLauncher;
    private final Job jobReporteTransaccionesDiarias;

    public BatchScheduler(JobLauncher jobLauncher,
                          @Qualifier("jobReporteTransaccionesDiarias") Job job) {
        this.jobLauncher = jobLauncher;
        this.jobReporteTransaccionesDiarias = job;
    }

    // Cada dia a las 02:00 (configurable). Desactivado si batch.scheduler.enabled=false.
    @Scheduled(cron = "${batch.scheduler.cron:0 0 2 * * *}")
    public void ejecutarReporteDiario() {
        ejecutarConReejecucion(jobReporteTransaccionesDiarias);
    }

    private void ejecutarConReejecucion(Job job) {
        int intento = 0;
        BatchStatus estado;
        do {
            try {
                JobParameters params = new JobParametersBuilder()
                        .addLong("timestamp", System.currentTimeMillis())
                        .addLong("intento", (long) intento)
                        .toJobParameters();
                JobExecution exec = jobLauncher.run(job, params);
                estado = exec.getStatus();
                log.info("Job '{}' intento {} -> {}", job.getName(), intento, estado);
            } catch (Exception e) {
                estado = BatchStatus.FAILED;
                log.error("Fallo critico ejecutando '{}': {}", job.getName(), e.getMessage());
            }
            intento++;
        } while (estado == BatchStatus.FAILED && intento <= MAX_REINTENTOS);
    }
}
