package cl.bancoxyz.batch.processor;

import cl.bancoxyz.batch.domain.InteresCalculado;
import cl.bancoxyz.batch.domain.InteresRaw;
import cl.bancoxyz.batch.exception.RegistroInvalidoException;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Procesa el "Calculo de Intereses".
 * Omite duplicados, saldos faltantes y edades fuera de rango (0-120).
 * Aplica la tasa segun el tipo de cuenta y calcula el saldo final.
 */
@Component
public class InteresProcessor implements ItemProcessor<InteresRaw, InteresCalculado> {

    // Tasas de interes por tipo de producto (valores de ejemplo del negocio).
    private static final Map<String, BigDecimal> TASAS = Map.of(
            "ahorro", new BigDecimal("0.015"),
            "prestamo", new BigDecimal("0.025"),
            "hipoteca", new BigDecimal("0.010")
    );

    // Deteccion de duplicados por cuentaId dentro de la ejecucion.
    private final Map<Long, Boolean> vistos = new ConcurrentHashMap<>();

    @Override
    public InteresCalculado process(InteresRaw raw) {
        if (raw.getCuentaId() == null || raw.getCuentaId().isBlank()) {
            throw new RegistroInvalidoException("cuentaId vacio");
        }
        long cuentaId;
        try {
            cuentaId = Long.parseLong(raw.getCuentaId().trim());
        } catch (NumberFormatException e) {
            throw new RegistroInvalidoException("cuentaId no numerico: " + raw.getCuentaId());
        }
        if (vistos.putIfAbsent(cuentaId, Boolean.TRUE) != null) {
            throw new RegistroInvalidoException("Registro duplicado para cuentaId=" + cuentaId);
        }
        if (raw.getSaldo() == null || raw.getSaldo().isBlank()) {
            throw new RegistroInvalidoException("Saldo faltante en cuentaId=" + cuentaId);
        }
        BigDecimal saldo;
        try {
            saldo = new BigDecimal(raw.getSaldo().trim());
        } catch (NumberFormatException e) {
            throw new RegistroInvalidoException("Saldo no numerico en cuentaId=" + cuentaId);
        }
        Integer edad = null;
        try {
            if (raw.getEdad() != null && !raw.getEdad().isBlank()) {
                edad = Integer.parseInt(raw.getEdad().trim());
            }
        } catch (NumberFormatException e) {
            throw new RegistroInvalidoException("Edad no numerica en cuentaId=" + cuentaId);
        }
        if (edad == null || edad < 0 || edad > 120) {
            throw new RegistroInvalidoException("Edad fuera de rango en cuentaId=" + cuentaId);
        }
        String tipo = raw.getTipo() == null ? "" : raw.getTipo().trim().toLowerCase();
        BigDecimal tasa = TASAS.get(tipo);
        if (tasa == null) {
            throw new RegistroInvalidoException("Tipo de cuenta desconocido '" + tipo + "' en cuentaId=" + cuentaId);
        }

        BigDecimal interes = saldo.multiply(tasa).setScale(2, RoundingMode.HALF_UP);

        InteresCalculado ic = new InteresCalculado();
        ic.setCuentaId(cuentaId);
        ic.setNombre(raw.getNombre() == null ? "" : raw.getNombre().trim());
        ic.setSaldo(saldo);
        ic.setEdad(edad);
        ic.setTipo(tipo);
        ic.setTasaAplicada(tasa);
        ic.setInteresCalculado(interes);
        ic.setSaldoFinal(saldo.add(interes));
        return ic;
    }
}
