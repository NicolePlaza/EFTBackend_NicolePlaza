package cl.bancoxyz.batch.processor;

import cl.bancoxyz.batch.domain.MovimientoDiarioRaw;
import cl.bancoxyz.batch.domain.MovimientoProcesado;
import cl.bancoxyz.batch.exception.RegistroInvalidoException;
import cl.bancoxyz.batch.mapper.FechaUtil;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Set;

/**
 * Procesa el "Reporte de Transacciones Diarias".
 * Valida estructura (fecha, monto numerico) y marca anomalias de negocio
 * (monto <= 0, tipo desconocido/invalido) para su posterior analisis.
 * Equivalente funcional del script legacy que detectaba anomalias.
 */
@Component
public class MovimientoDiarioProcessor implements ItemProcessor<MovimientoDiarioRaw, MovimientoProcesado> {

    private static final Set<String> TIPOS_VALIDOS = Set.of("debito", "credito");

    @Override
    public MovimientoProcesado process(MovimientoDiarioRaw raw) {
        // Registro estructuralmente invalido -> se omite (skip).
        if (raw.getId() == null || raw.getId().isBlank()) {
            throw new RegistroInvalidoException("Id de movimiento vacio");
        }
        long id;
        try {
            id = Long.parseLong(raw.getId().trim());
        } catch (NumberFormatException e) {
            throw new RegistroInvalidoException("Id no numerico: " + raw.getId());
        }
        if (raw.getMonto() == null || raw.getMonto().isBlank()) {
            throw new RegistroInvalidoException("Monto vacio en id=" + id);
        }
        BigDecimal monto;
        try {
            monto = new BigDecimal(raw.getMonto().trim());
        } catch (NumberFormatException e) {
            throw new RegistroInvalidoException("Monto no numerico en id=" + id);
        }

        MovimientoProcesado m = new MovimientoProcesado();
        m.setIdOrigen(id);
        m.setFecha(FechaUtil.parsear(raw.getFecha()));
        m.setMonto(monto);
        String tipo = raw.getTipo() == null ? "" : raw.getTipo().trim().toLowerCase();
        m.setTipo(tipo);

        // Deteccion de anomalias (se conservan, no se descartan).
        StringBuilder motivo = new StringBuilder();
        if (monto.compareTo(BigDecimal.ZERO) <= 0) {
            motivo.append("monto<=0;");
        }
        if (!TIPOS_VALIDOS.contains(tipo)) {
            motivo.append("tipo-no-reconocido;");
        }
        if (motivo.length() > 0) {
            m.setAnomalia(true);
            m.setMotivoAnomalia(motivo.toString());
        }
        return m;
    }
}
