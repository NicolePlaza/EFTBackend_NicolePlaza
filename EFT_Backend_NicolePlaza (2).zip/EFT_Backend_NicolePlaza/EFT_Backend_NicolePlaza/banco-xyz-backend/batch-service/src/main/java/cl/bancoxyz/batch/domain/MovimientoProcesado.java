package cl.bancoxyz.batch.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/** Resultado del proceso "Reporte de Transacciones Diarias". */
@Entity
@Table(name = "movimiento_procesado")
public class MovimientoProcesado {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long idOrigen;
    private LocalDate fecha;
    private BigDecimal monto;
    private String tipo;
    private boolean anomalia;
    private String motivoAnomalia;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getIdOrigen() { return idOrigen; }
    public void setIdOrigen(Long idOrigen) { this.idOrigen = idOrigen; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public BigDecimal getMonto() { return monto; }
    public void setMonto(BigDecimal monto) { this.monto = monto; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public boolean isAnomalia() { return anomalia; }
    public void setAnomalia(boolean anomalia) { this.anomalia = anomalia; }
    public String getMotivoAnomalia() { return motivoAnomalia; }
    public void setMotivoAnomalia(String motivoAnomalia) { this.motivoAnomalia = motivoAnomalia; }
}
