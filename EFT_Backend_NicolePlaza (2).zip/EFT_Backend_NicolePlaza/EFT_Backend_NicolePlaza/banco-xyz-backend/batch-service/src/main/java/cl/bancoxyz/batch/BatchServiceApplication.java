package cl.bancoxyz.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Microservicio de procesos batch (Parte 1).
 * Reescribe en Spring Batch los tres procesos legacy del Banco XYZ:
 *  - Reporte de Transacciones Diarias
 *  - Calculo de Intereses (cuentas de ahorro / prestamos / hipotecas)
 *  - Generacion de Estados de Cuenta Anuales
 * Incorpora tolerancia a fallos (skip + retry), paralelismo por chunks y
 * politica de reejecucion para fallos criticos.
 */
@SpringBootApplication
@EnableScheduling
public class BatchServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(BatchServiceApplication.class, args);
    }
}
