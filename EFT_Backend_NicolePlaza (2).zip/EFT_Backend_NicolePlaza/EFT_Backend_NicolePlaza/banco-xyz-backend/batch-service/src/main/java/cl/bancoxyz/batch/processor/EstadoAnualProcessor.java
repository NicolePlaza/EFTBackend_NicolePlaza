package cl.bancoxyz.batch.processor;

import cl.bancoxyz.batch.domain.EstadoAnualRaw;
import cl.bancoxyz.batch.domain.MovimientoAnual;
import cl.bancoxyz.batch.exception.RegistroInvalidoException;
import cl.bancoxyz.batch.mapper.FechaUtil;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Procesa la "Generacion de Estados de Cuenta Anuales".
 * Normaliza fechas mal formateadas, exige monto numerico y descripcion no vacia,
 * y rechaza montos negativos para compras/depositos.
 */
@Component
public class EstadoAnualProcessor implements ItemProcessor<EstadoAnualRaw, MovimientoAnual> {

    @Override
    public MovimientoAnual process(EstadoAnualRaw raw) {
        if (raw.getCuentaId() == null || raw.getCuentaId().isBlank()) {
            throw new RegistroInvalidoException("cuentaId vacio");
        }
        long cuentaId;
        try {
            cuentaId = Long.parseLong(raw.getCuentaId().trim());
        } catch (NumberFormatException e) {
            throw new RegistroInvalidoException("cuentaId no numerico: " + raw.getCuentaId());
        }
        if (raw.getDescripcion() == null || raw.getDescripcion().trim().isEmpty()) {
            throw new RegistroInvalidoException("Descripcion vacia en cuentaId=" + cuentaId);
        }
        if (raw.getMonto() == null || raw.getMonto().isBlank()) {
            throw new RegistroInvalidoException("Monto vacio en cuentaId=" + cuentaId);
        }
        BigDecimal monto;
        try {
            monto = new BigDecimal(raw.getMonto().trim());
        } catch (NumberFormatException e) {
            throw new RegistroInvalidoException("Monto no numerico en cuentaId=" + cuentaId);
        }
        String transaccion = raw.getTransaccion() == null ? "" : raw.getTransaccion().trim().toLowerCase();
        // Un deposito o compra con monto negativo es inconsistente.
        if ((transaccion.startsWith("deposito") || transaccion.startsWith("depósito") || transaccion.equals("compra"))
                && monto.compareTo(BigDecimal.ZERO) < 0) {
            throw new RegistroInvalidoException("Monto negativo invalido para " + transaccion + " en cuentaId=" + cuentaId);
        }

        MovimientoAnual m = new MovimientoAnual();
        m.setCuentaId(cuentaId);
        m.setFecha(FechaUtil.parsear(raw.getFecha()));
        m.setTransaccion(transaccion);
        m.setMonto(monto);
        m.setDescripcion(raw.getDescripcion().trim());
        return m;
    }
}
