package cl.bancoxyz.batch.batch;

import cl.bancoxyz.batch.domain.*;
import cl.bancoxyz.batch.exception.RegistroInvalidoException;
import cl.bancoxyz.batch.listener.JobCompletionListener;
import cl.bancoxyz.batch.listener.LoggingSkipListener;
import cl.bancoxyz.batch.processor.EstadoAnualProcessor;
import cl.bancoxyz.batch.processor.InteresProcessor;
import cl.bancoxyz.batch.processor.MovimientoDiarioProcessor;
import jakarta.persistence.EntityManagerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.database.builder.JpaItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.support.SynchronizedItemStreamReader;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.task.TaskExecutor;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * Configuracion de los tres procesos batch migrados desde el legacy.
 *
 * Caracteristicas transversales exigidas por el caso:
 *  - Steps con lectura (FlatFileItemReader), proceso (ItemProcessor) y
 *    escritura (JpaItemWriter), en chunks de 100.
 *  - Tolerancia a fallos: skip de registros invalidos (RegistroInvalidoException)
 *    y retry ante fallos temporales de BD (TransientDataAccessException).
 *  - Paralelismo: el proceso de alto volumen usa un step multi-hilo.
 *  - Reejecucion: RunIdIncrementer permite relanzar el job tras un fallo critico.
 */
@Configuration
public class BatchConfig {

    private static final int CHUNK = 100;
    private static final int SKIP_LIMIT = 2000;
    private static final int RETRY_LIMIT = 3;

    // ---------------------------------------------------------------------
    // TaskExecutor para el procesamiento paralelo de grandes volumenes.
    // ---------------------------------------------------------------------
    @Bean
    public TaskExecutor batchTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(8);
        executor.setQueueCapacity(50);
        executor.setThreadNamePrefix("batch-worker-");
        executor.initialize();
        return executor;
    }

    // =====================================================================
    // PROCESO 1: Reporte de Transacciones Diarias
    // =====================================================================
    @Bean
    @org.springframework.batch.core.configuration.annotation.StepScope
    public FlatFileItemReader<MovimientoDiarioRaw> movimientoDiarioReader(
            @org.springframework.beans.factory.annotation.Value(
                "#{jobParameters['inputDiarios'] ?: 'classpath:data/movimientos_financieros_diarios.csv'}") Resource recurso) {
        return new FlatFileItemReaderBuilder<MovimientoDiarioRaw>()
                .name("movimientoDiarioReader")
                .resource(recurso)
                .linesToSkip(1) // encabezado
                .delimited().names("id", "fecha", "monto", "tipo")
                .targetType(MovimientoDiarioRaw.class)
                .build();
    }

    /** Reader sincronizado para uso seguro en step multi-hilo. */
    @Bean
    public SynchronizedItemStreamReader<MovimientoDiarioRaw> movimientoDiarioSyncReader(
            FlatFileItemReader<MovimientoDiarioRaw> movimientoDiarioReader) {
        SynchronizedItemStreamReader<MovimientoDiarioRaw> reader = new SynchronizedItemStreamReader<>();
        reader.setDelegate(movimientoDiarioReader);
        return reader;
    }

    @Bean
    public JpaItemWriter<MovimientoProcesado> movimientoProcesadoWriter(EntityManagerFactory emf) {
        return new JpaItemWriterBuilder<MovimientoProcesado>().entityManagerFactory(emf).build();
    }

    @Bean
    public Step stepTransaccionesDiarias(JobRepository jobRepository,
                                         PlatformTransactionManager tx,
                                         SynchronizedItemStreamReader<MovimientoDiarioRaw> movimientoDiarioSyncReader,
                                         MovimientoDiarioProcessor processor,
                                         JpaItemWriter<MovimientoProcesado> writer,
                                         LoggingSkipListener skipListener,
                                         TaskExecutor batchTaskExecutor) {
        return new StepBuilder("stepTransaccionesDiarias", jobRepository)
                .<MovimientoDiarioRaw, MovimientoProcesado>chunk(CHUNK, tx)
                .reader(movimientoDiarioSyncReader)
                .processor(processor)
                .writer(writer)
                .faultTolerant()
                .skip(RegistroInvalidoException.class).skipLimit(SKIP_LIMIT)
                .retry(TransientDataAccessException.class).retry(CannotAcquireLockException.class).retryLimit(RETRY_LIMIT)
                .listener(skipListener)
                // Paralelismo: procesa varios chunks en simultaneo para alto volumen.
                .taskExecutor(batchTaskExecutor)
                .build();
    }

    @Bean
    public Job jobReporteTransaccionesDiarias(JobRepository jobRepository,
                                              Step stepTransaccionesDiarias,
                                              JobCompletionListener jobListener) {
        return new JobBuilder("jobReporteTransaccionesDiarias", jobRepository)
                .incrementer(new RunIdIncrementer()) // permite reejecucion
                .listener(jobListener)
                .start(stepTransaccionesDiarias)
                .build();
    }

    // =====================================================================
    // PROCESO 2: Calculo de Intereses
    // =====================================================================
    @Bean
    @org.springframework.batch.core.configuration.annotation.StepScope
    public FlatFileItemReader<InteresRaw> interesReader(
            @org.springframework.beans.factory.annotation.Value(
                "#{jobParameters['inputIntereses'] ?: 'classpath:data/intereses_trimestrales.csv'}") Resource recurso) {
        return new FlatFileItemReaderBuilder<InteresRaw>()
                .name("interesReader")
                .resource(recurso)
                .linesToSkip(1)
                .delimited().names("cuentaId", "nombre", "saldo", "edad", "tipo")
                .targetType(InteresRaw.class)
                .build();
    }

    @Bean
    public JpaItemWriter<InteresCalculado> interesWriter(EntityManagerFactory emf) {
        return new JpaItemWriterBuilder<InteresCalculado>().entityManagerFactory(emf).build();
    }

    @Bean
    public Step stepCalculoIntereses(JobRepository jobRepository,
                                     PlatformTransactionManager tx,
                                     FlatFileItemReader<InteresRaw> interesReader,
                                     InteresProcessor processor,
                                     JpaItemWriter<InteresCalculado> interesWriter,
                                     LoggingSkipListener skipListener) {
        return new StepBuilder("stepCalculoIntereses", jobRepository)
                .<InteresRaw, InteresCalculado>chunk(CHUNK, tx)
                .reader(interesReader)
                .processor(processor)
                .writer(interesWriter)
                .faultTolerant()
                .skip(RegistroInvalidoException.class).skipLimit(SKIP_LIMIT)
                .retry(TransientDataAccessException.class).retryLimit(RETRY_LIMIT)
                .listener(skipListener)
                .build();
    }

    @Bean
    public Job jobCalculoInteresesMensuales(JobRepository jobRepository,
                                            Step stepCalculoIntereses,
                                            JobCompletionListener jobListener) {
        return new JobBuilder("jobCalculoInteresesMensuales", jobRepository)
                .incrementer(new RunIdIncrementer())
                .listener(jobListener)
                .start(stepCalculoIntereses)
                .build();
    }

    // =====================================================================
    // PROCESO 3: Generacion de Estados de Cuenta Anuales
    // =====================================================================
    @Bean
    @org.springframework.batch.core.configuration.annotation.StepScope
    public FlatFileItemReader<EstadoAnualRaw> estadoAnualReader(
            @org.springframework.beans.factory.annotation.Value(
                "#{jobParameters['inputAnuales'] ?: 'classpath:data/estados_financieros_anuales.csv'}") Resource recurso) {
        return new FlatFileItemReaderBuilder<EstadoAnualRaw>()
                .name("estadoAnualReader")
                .resource(recurso)
                .linesToSkip(1)
                .delimited().names("cuentaId", "fecha", "transaccion", "monto", "descripcion")
                .targetType(EstadoAnualRaw.class)
                .build();
    }

    @Bean
    public JpaItemWriter<MovimientoAnual> movimientoAnualWriter(EntityManagerFactory emf) {
        return new JpaItemWriterBuilder<MovimientoAnual>().entityManagerFactory(emf).build();
    }

    @Bean
    public Step stepEstadosAnuales(JobRepository jobRepository,
                                   PlatformTransactionManager tx,
                                   FlatFileItemReader<EstadoAnualRaw> estadoAnualReader,
                                   EstadoAnualProcessor processor,
                                   JpaItemWriter<MovimientoAnual> movimientoAnualWriter,
                                   LoggingSkipListener skipListener) {
        return new StepBuilder("stepEstadosAnuales", jobRepository)
                .<EstadoAnualRaw, MovimientoAnual>chunk(CHUNK, tx)
                .reader(estadoAnualReader)
                .processor(processor)
                .writer(movimientoAnualWriter)
                .faultTolerant()
                .skip(RegistroInvalidoException.class).skipLimit(SKIP_LIMIT)
                .retry(TransientDataAccessException.class).retryLimit(RETRY_LIMIT)
                .listener(skipListener)
                .build();
    }

    @Bean
    public Job jobEstadosCuentaAnuales(JobRepository jobRepository,
                                       Step stepEstadosAnuales,
                                       JobCompletionListener jobListener) {
        return new JobBuilder("jobEstadosCuentaAnuales", jobRepository)
                .incrementer(new RunIdIncrementer())
                .listener(jobListener)
                .start(stepEstadosAnuales)
                .build();
    }
}
