package cl.bancoxyz.bffmovil.dto;

import java.math.BigDecimal;

public record CuentaDTO(Long id, Long clienteId, String tipo, BigDecimal saldo, String estado) {
}
