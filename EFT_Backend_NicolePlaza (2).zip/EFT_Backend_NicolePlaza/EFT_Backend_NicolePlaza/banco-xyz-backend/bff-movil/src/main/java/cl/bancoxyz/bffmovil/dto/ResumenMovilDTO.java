package cl.bancoxyz.bffmovil.dto;

import java.math.BigDecimal;
import java.util.List;

/**
 * Carga util minima para movil: saldo total, cantidad de cuentas y un listado
 * reducido (id, tipo, saldo). Se omiten campos pesados o innecesarios.
 */
public record ResumenMovilDTO(BigDecimal saldoTotal, int cantidadCuentas, List<CuentaLigera> cuentas) {
    public record CuentaLigera(Long id, String tipo, BigDecimal saldo) {}
}
