package cl.bancoxyz.bffmovil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * BFF Movil: respuestas ligeras. Devuelve solo los datos esenciales (saldo
 * total y numero de cuentas) para reducir el consumo de ancho de banda y
 * acelerar la carga en dispositivos moviles.
 */
@SpringBootApplication
@EnableFeignClients
public class BffMovilApplication {
    public static void main(String[] args) {
        SpringApplication.run(BffMovilApplication.class, args);
    }
}
