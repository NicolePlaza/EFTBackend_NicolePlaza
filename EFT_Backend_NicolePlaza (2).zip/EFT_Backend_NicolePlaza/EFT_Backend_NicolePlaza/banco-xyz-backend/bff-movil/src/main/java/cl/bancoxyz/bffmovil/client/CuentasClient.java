package cl.bancoxyz.bffmovil.client;

import cl.bancoxyz.bffmovil.dto.CuentaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "cuentas-service")
public interface CuentasClient {
    @GetMapping("/api/cuentas")
    List<CuentaDTO> porCliente(@RequestParam("clienteId") Long clienteId);
}
