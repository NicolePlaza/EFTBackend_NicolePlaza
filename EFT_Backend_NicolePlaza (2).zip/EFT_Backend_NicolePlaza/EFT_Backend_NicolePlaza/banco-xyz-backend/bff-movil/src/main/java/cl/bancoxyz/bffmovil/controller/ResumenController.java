package cl.bancoxyz.bffmovil.controller;

import cl.bancoxyz.bffmovil.client.CuentasClient;
import cl.bancoxyz.bffmovil.dto.CuentaDTO;
import cl.bancoxyz.bffmovil.dto.ResumenMovilDTO;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

/** Devuelve un resumen ligero del cliente, pensado para redes moviles. */
@RestController
@RequestMapping("/api/movil")
public class ResumenController {

    private final CuentasClient cuentasClient;

    public ResumenController(CuentasClient cuentasClient) {
        this.cuentasClient = cuentasClient;
    }

    @GetMapping("/resumen/{clienteId}")
    @CircuitBreaker(name = "backendServices", fallbackMethod = "fallback")
    public ResumenMovilDTO resumen(@PathVariable Long clienteId) {
        List<CuentaDTO> cuentas = cuentasClient.porCliente(clienteId);
        BigDecimal total = cuentas.stream()
                .map(CuentaDTO::saldo)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        List<ResumenMovilDTO.CuentaLigera> ligeras = cuentas.stream()
                .map(c -> new ResumenMovilDTO.CuentaLigera(c.id(), c.tipo(), c.saldo()))
                .toList();
        return new ResumenMovilDTO(total, cuentas.size(), ligeras);
    }

    @SuppressWarnings("unused")
    private ResumenMovilDTO fallback(Long clienteId, Throwable t) {
        return new ResumenMovilDTO(BigDecimal.ZERO, 0, List.of());
    }
}
