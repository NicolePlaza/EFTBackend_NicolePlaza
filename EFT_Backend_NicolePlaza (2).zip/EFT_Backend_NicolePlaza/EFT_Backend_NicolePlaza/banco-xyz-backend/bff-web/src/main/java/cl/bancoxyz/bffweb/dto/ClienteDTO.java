package cl.bancoxyz.bffweb.dto;

public record ClienteDTO(Long id, String rut, String nombre, String email,
                         String telefono, String segmento) {
}
