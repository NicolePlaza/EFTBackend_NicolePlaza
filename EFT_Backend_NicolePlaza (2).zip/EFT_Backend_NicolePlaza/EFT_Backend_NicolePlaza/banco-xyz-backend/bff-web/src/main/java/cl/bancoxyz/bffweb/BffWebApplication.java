package cl.bancoxyz.bffweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * BFF Web: optimizado para navegadores. Agrega en una sola respuesta los datos
 * completos del cliente y todas sus cuentas con detalle, evitando multiples
 * llamadas desde el frontend web.
 */
@SpringBootApplication
@EnableFeignClients
public class BffWebApplication {
    public static void main(String[] args) {
        SpringApplication.run(BffWebApplication.class, args);
    }
}
