package cl.bancoxyz.bffweb.dto;

import java.util.List;

/** Respuesta completa agregada para el frontend web. */
public record DashboardWebDTO(ClienteDTO cliente, List<CuentaDTO> cuentas) {
}
