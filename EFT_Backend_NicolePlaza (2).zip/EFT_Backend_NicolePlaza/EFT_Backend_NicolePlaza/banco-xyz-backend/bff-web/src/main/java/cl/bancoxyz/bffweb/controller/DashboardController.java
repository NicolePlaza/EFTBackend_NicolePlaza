package cl.bancoxyz.bffweb.controller;

import cl.bancoxyz.bffweb.client.ClientesClient;
import cl.bancoxyz.bffweb.client.CuentasClient;
import cl.bancoxyz.bffweb.dto.DashboardWebDTO;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Entrega la vista completa (cliente + cuentas) en una sola llamada.
 * Protegido con circuit breaker para degradar con elegancia si un
 * microservicio no responde.
 */
@RestController
@RequestMapping("/api/web")
public class DashboardController {

    private final ClientesClient clientesClient;
    private final CuentasClient cuentasClient;

    public DashboardController(ClientesClient clientesClient, CuentasClient cuentasClient) {
        this.clientesClient = clientesClient;
        this.cuentasClient = cuentasClient;
    }

    @GetMapping("/dashboard/{clienteId}")
    @CircuitBreaker(name = "backendServices", fallbackMethod = "fallback")
    public DashboardWebDTO dashboard(@PathVariable Long clienteId) {
        var cliente = clientesClient.obtener(clienteId);
        var cuentas = cuentasClient.porCliente(clienteId);
        return new DashboardWebDTO(cliente, cuentas);
    }

    @SuppressWarnings("unused")
    private DashboardWebDTO fallback(Long clienteId, Throwable t) {
        // Degradacion: devuelve estructura vacia en lugar de propagar el error.
        return new DashboardWebDTO(null, List.of());
    }
}
