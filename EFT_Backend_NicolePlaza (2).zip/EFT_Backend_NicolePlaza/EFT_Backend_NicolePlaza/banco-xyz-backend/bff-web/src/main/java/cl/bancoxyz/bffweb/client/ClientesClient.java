package cl.bancoxyz.bffweb.client;

import cl.bancoxyz.bffweb.dto.ClienteDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "clientes-service")
public interface ClientesClient {
    @GetMapping("/api/clientes/{id}")
    ClienteDTO obtener(@PathVariable("id") Long id);
}
