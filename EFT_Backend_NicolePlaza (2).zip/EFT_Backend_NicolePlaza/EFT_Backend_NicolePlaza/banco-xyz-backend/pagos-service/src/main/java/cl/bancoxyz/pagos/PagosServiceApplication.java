package cl.bancoxyz.pagos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Microservicio de Procesamiento de Pagos: pagos, transferencias y depositos.
 * Llama a cuentas-service mediante Feign protegido con Resilience4j (circuit
 * breaker + fallback) y publica eventos en Kafka (productor).
 */
@SpringBootApplication
@EnableFeignClients
public class PagosServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(PagosServiceApplication.class, args);
    }
}
