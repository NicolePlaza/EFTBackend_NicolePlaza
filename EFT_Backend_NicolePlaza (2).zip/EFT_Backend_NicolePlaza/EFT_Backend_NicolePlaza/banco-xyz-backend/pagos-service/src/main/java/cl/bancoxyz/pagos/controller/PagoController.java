package cl.bancoxyz.pagos.controller;

import cl.bancoxyz.pagos.domain.Pago;
import cl.bancoxyz.pagos.dto.PagoRequest;
import cl.bancoxyz.pagos.service.PagoService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pagos")
public class PagoController {

    private final PagoService service;

    public PagoController(PagoService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SCOPE_pagos.write')")
    public Pago procesar(@Valid @RequestBody PagoRequest req) {
        return service.procesar(req);
    }
}
