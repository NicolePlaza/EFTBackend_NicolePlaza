package cl.bancoxyz.pagos.dto;

import java.math.BigDecimal;

/** Vista de cuenta devuelta por cuentas-service. */
public record CuentaDTO(Long id, Long clienteId, String tipo, BigDecimal saldo, String estado) {
}
