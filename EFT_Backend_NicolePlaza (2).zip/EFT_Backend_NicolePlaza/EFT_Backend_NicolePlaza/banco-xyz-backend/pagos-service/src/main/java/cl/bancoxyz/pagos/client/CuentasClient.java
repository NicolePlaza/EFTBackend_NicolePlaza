package cl.bancoxyz.pagos.client;

import cl.bancoxyz.pagos.dto.CuentaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Cliente Feign hacia cuentas-service. El nombre 'cuentas-service' se resuelve
 * via Eureka y se balancea la carga automaticamente.
 */
@FeignClient(name = "cuentas-service")
public interface CuentasClient {

    @GetMapping("/api/cuentas/{id}")
    CuentaDTO obtenerCuenta(@PathVariable("id") Long id);
}
