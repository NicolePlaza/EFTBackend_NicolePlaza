package cl.bancoxyz.pagos.repository;

import cl.bancoxyz.pagos.domain.Pago;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagoRepository extends JpaRepository<Pago, Long> {
}
