package cl.bancoxyz.pagos.service;

import cl.bancoxyz.pagos.client.CuentasClient;
import cl.bancoxyz.pagos.domain.Pago;
import cl.bancoxyz.pagos.dto.CuentaDTO;
import cl.bancoxyz.pagos.dto.PagoRequest;
import cl.bancoxyz.pagos.messaging.AlertaSeguridadEvent;
import cl.bancoxyz.pagos.messaging.TransaccionCompletadaEvent;
import cl.bancoxyz.pagos.messaging.TransaccionProducer;
import cl.bancoxyz.pagos.repository.PagoRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Procesa pagos, transferencias y depositos.
 * La verificacion de la cuenta origen se protege con Resilience4j: si
 * cuentas-service no responde, el circuit breaker abre y ejecuta un
 * comportamiento alternativo (fallback) sin propagar el fallo.
 */
@Service
public class PagoService {

    private static final Logger log = LoggerFactory.getLogger(PagoService.class);
    private static final BigDecimal UMBRAL_ALERTA = new BigDecimal("10000000"); // 10 millones

    private final CuentasClient cuentasClient;
    private final PagoRepository repo;
    private final TransaccionProducer producer;

    public PagoService(CuentasClient cuentasClient, PagoRepository repo, TransaccionProducer producer) {
        this.cuentasClient = cuentasClient;
        this.repo = repo;
        this.producer = producer;
    }

    public Pago procesar(PagoRequest req) {
        // Para pagos y transferencias se valida la cuenta origen.
        boolean requiereOrigen = !"deposito".equalsIgnoreCase(req.tipo());
        if (requiereOrigen && req.cuentaOrigenId() != null) {
            CuentaDTO cuenta = verificarCuenta(req.cuentaOrigenId());
            if (cuenta != null && !"ACTIVA".equals(cuenta.estado())) {
                throw new IllegalStateException("La cuenta origen no esta activa");
            }
        }

        Pago pago = new Pago();
        pago.setCuentaOrigenId(req.cuentaOrigenId());
        pago.setCuentaDestinoId(req.cuentaDestinoId());
        pago.setMonto(req.monto());
        pago.setTipo(req.tipo().toLowerCase());
        pago.setEstado("CONFIRMADO");
        pago = repo.save(pago);

        String txId = UUID.randomUUID().toString();
        producer.publicarTransaccion(new TransaccionCompletadaEvent(
                txId, pago.getCuentaOrigenId(), pago.getCuentaDestinoId(),
                pago.getMonto(), pago.getTipo()));

        // Regla de seguridad: monto elevado dispara alerta.
        if (pago.getMonto().compareTo(UMBRAL_ALERTA) >= 0) {
            producer.publicarAlerta(new AlertaSeguridadEvent(
                    txId, pago.getCuentaOrigenId(), pago.getMonto(),
                    "Monto superior al umbral permitido"));
        }
        return pago;
    }

    /**
     * Llamada protegida: circuit breaker + reintentos. Si cuentas-service falla
     * de forma persistente, se invoca el fallback.
     */
    @CircuitBreaker(name = "cuentasService", fallbackMethod = "fallbackCuenta")
    @Retry(name = "cuentasService")
    public CuentaDTO verificarCuenta(Long cuentaId) {
        return cuentasClient.obtenerCuenta(cuentaId);
    }

    /** Comportamiento alternativo ante indisponibilidad de cuentas-service. */
    @SuppressWarnings("unused")
    private CuentaDTO fallbackCuenta(Long cuentaId, Throwable t) {
        log.warn("Fallback de cuentas-service para cuentaId={}: {}", cuentaId, t.getMessage());
        // Se asume estado desconocido pero no se bloquea la operacion; queda
        // registrada para conciliacion posterior.
        return null;
    }
}
