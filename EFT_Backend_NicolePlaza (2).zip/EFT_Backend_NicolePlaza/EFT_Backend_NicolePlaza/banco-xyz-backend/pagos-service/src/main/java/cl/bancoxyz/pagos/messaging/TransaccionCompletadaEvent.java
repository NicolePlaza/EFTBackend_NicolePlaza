package cl.bancoxyz.pagos.messaging;

import java.math.BigDecimal;

public record TransaccionCompletadaEvent(
        String transaccionId,
        Long cuentaOrigenId,
        Long cuentaDestinoId,
        BigDecimal monto,
        String tipo) {
}
