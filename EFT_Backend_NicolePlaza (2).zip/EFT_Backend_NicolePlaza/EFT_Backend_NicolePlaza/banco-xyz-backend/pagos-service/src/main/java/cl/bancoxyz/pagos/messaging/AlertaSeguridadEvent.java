package cl.bancoxyz.pagos.messaging;

import java.math.BigDecimal;

public record AlertaSeguridadEvent(
        String transaccionId,
        Long cuentaOrigenId,
        BigDecimal monto,
        String motivo) {
}
