package cl.bancoxyz.pagos.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

public record PagoRequest(
        Long cuentaOrigenId,
        Long cuentaDestinoId,
        @NotNull @Positive BigDecimal monto,
        @NotBlank String tipo) {
}
