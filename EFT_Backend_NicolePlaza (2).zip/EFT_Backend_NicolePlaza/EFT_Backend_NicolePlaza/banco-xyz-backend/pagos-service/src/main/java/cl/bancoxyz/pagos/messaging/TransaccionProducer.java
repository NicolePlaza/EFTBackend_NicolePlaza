package cl.bancoxyz.pagos.messaging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/**
 * Productor Kafka. Publica eventos de transacciones completadas y alertas de
 * seguridad para que otros microservicios reaccionen en tiempo real.
 */
@Component
public class TransaccionProducer {

    private static final Logger log = LoggerFactory.getLogger(TransaccionProducer.class);
    public static final String TOPIC_TRANSACCIONES = "transacciones-completadas";
    public static final String TOPIC_ALERTAS = "alertas-seguridad";

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public TransaccionProducer(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publicarTransaccion(TransaccionCompletadaEvent evento) {
        log.info("Publicando transaccion completada: {}", evento);
        kafkaTemplate.send(TOPIC_TRANSACCIONES, evento.transaccionId(), evento);
    }

    public void publicarAlerta(AlertaSeguridadEvent alerta) {
        log.warn("Publicando alerta de seguridad: {}", alerta);
        kafkaTemplate.send(TOPIC_ALERTAS, alerta.transaccionId(), alerta);
    }
}
