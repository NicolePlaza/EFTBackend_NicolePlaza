# Pasos para desplegar el sistema en un entorno de nube (AWS)

Este documento describe cómo desplegar el backend de microservicios del Banco
XYZ en un entorno de nube **AWS**, incluyendo contenedores, configuración,
seguridad y **escalabilidad horizontal**.

---

## 1. Estrategia general

El sistema se empaqueta en imágenes Docker (una por servicio) y se despliega en
AWS. Se proponen dos caminos, según madurez del equipo:

- **Opción A — Amazon ECS (Fargate):** orquestación administrada, sin gestionar
  servidores. Recomendada para esta entrega.
- **Opción B — Amazon EKS (Kubernetes):** mayor control y portabilidad.

Servicios gestionados de apoyo:
- **Amazon RDS (PostgreSQL)** para la persistencia.
- **Amazon MSK (Kafka administrado)** para la mensajería.
- **Amazon ECR** como registro de imágenes.
- **Application Load Balancer (ALB)** delante del API Gateway.
- **AWS Secrets Manager** para credenciales y secretos OAuth2.

---

## 2. Requisitos previos

- Cuenta AWS con permisos para ECR, ECS/EKS, RDS, MSK, IAM y VPC.
- **AWS CLI** configurada (`aws configure`).
- **Docker** instalado localmente.
- Imágenes construidas del proyecto (`docker compose build`).

---

## 3. Construir y publicar las imágenes en Amazon ECR

```bash
# Variables
export AWS_REGION=us-east-1
export ACCOUNT=<TU_ACCOUNT_ID>
export REGISTRY=$ACCOUNT.dkr.ecr.$AWS_REGION.amazonaws.com

# Autenticación en ECR
aws ecr get-login-password --region $AWS_REGION | \
  docker login --username AWS --password-stdin $REGISTRY

# Crear un repositorio por servicio y publicar
for SVC in config-server eureka-server api-gateway auth-server \
           cuentas-service pagos-service clientes-service \
           bff-web bff-movil bff-cajero batch-service; do
  aws ecr create-repository --repository-name bancoxyz/$SVC --region $AWS_REGION 2>/dev/null || true
  docker build -f $SVC/Dockerfile -t $REGISTRY/bancoxyz/$SVC:1.0.0 .
  docker push $REGISTRY/bancoxyz/$SVC:1.0.0
done
```

---

## 4. Infraestructura gestionada

### 4.1 Base de datos — Amazon RDS (PostgreSQL)

```bash
aws rds create-db-instance \
  --db-instance-identifier bancoxyz-db \
  --engine postgres --engine-version 16 \
  --db-instance-class db.t3.medium \
  --allocated-storage 20 \
  --master-username bancoxyz --master-user-password <SECRETO> \
  --db-name bancoxyz
```

Cada microservicio con persistencia (cuentas, pagos, clientes, batch) apunta a
RDS vía variables de entorno:

```
SPRING_DATASOURCE_URL=jdbc:postgresql://bancoxyz-db.xxxx.us-east-1.rds.amazonaws.com:5432/bancoxyz
SPRING_DATASOURCE_USERNAME=bancoxyz
SPRING_DATASOURCE_PASSWORD=<desde Secrets Manager>
SPRING_JPA_HIBERNATE_DDL_AUTO=validate
```

> Los módulos ya incluyen el driver de PostgreSQL. En nube se activa el perfil
> de BD real reemplazando las variables H2 por las de RDS.

### 4.2 Mensajería — Amazon MSK (Kafka)

Crea un clúster MSK y expón sus *bootstrap brokers*. Luego configura:

```
KAFKA_SERVERS=b-1.msk.xxxx.kafka.us-east-1.amazonaws.com:9092,b-2...:9092
```

### 4.3 Secretos — AWS Secrets Manager

Guarda los `client-secret` de OAuth2, credenciales de BD y claves. Inyéctalos
como variables de entorno en las *task definitions* de ECS.

---

## 5. Despliegue en Amazon ECS (Fargate) — Opción A

1. **Clúster:** `aws ecs create-cluster --cluster-name bancoxyz`.
2. **Task definition por servicio:** imagen de ECR, CPU/memoria, variables de
   entorno (`EUREKA_HOST`, `CONFIG_HOST`, `AUTH_HOST`, `KAFKA_SERVERS`, datasource),
   y *health check* contra `/actuator/health`.
3. **Service Discovery:** usa **AWS Cloud Map** para resolución interna, o
   mantén `eureka-server` como servicio ECS y apunta los demás a su DNS privado.
4. **ALB:** publica solo el `api-gateway` detrás de un Application Load Balancer
   con listener **HTTPS (443)** y certificado de **AWS Certificate Manager**.
   Los microservicios y BFF permanecen en subredes privadas.
5. **Orden de despliegue:** `config-server` → `eureka-server` → `auth-server` →
   resto de servicios.

Ejemplo de creación de un servicio con réplicas:

```bash
aws ecs create-service \
  --cluster bancoxyz \
  --service-name pagos-service \
  --task-definition pagos-service:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx],securityGroups=[sg-xxx]}"
```

---

## 6. Escalabilidad horizontal

La arquitectura está diseñada para **escalar por instancias** (criterio 6):

- Los servicios son **stateless** (sesión JWT, sin estado en memoria), por lo que
  pueden replicarse sin afectar la consistencia.
- **Eureka + balanceo** (lb:// en el Gateway y Feign) distribuyen la carga entre
  instancias automáticamente al registrarse nuevas réplicas.

**En local (Docker Compose):**
```bash
docker compose up -d --scale pagos-service=3 --scale cuentas-service=2
```

**En ECS — autoescalado por métrica:**
```bash
aws application-autoscaling register-scalable-target \
  --service-namespace ecs \
  --resource-id service/bancoxyz/pagos-service \
  --scalable-dimension ecs:service:DesiredCount \
  --min-capacity 2 --max-capacity 10

aws application-autoscaling put-scaling-policy \
  --service-namespace ecs \
  --resource-id service/bancoxyz/pagos-service \
  --scalable-dimension ecs:service:DesiredCount \
  --policy-name cpu-scaling --policy-type TargetTrackingScaling \
  --target-tracking-scaling-policy-configuration \
  '{"TargetValue":60.0,"PredefinedMetricSpecification":{"PredefinedMetricType":"ECSServiceAverageCPUUtilization"}}'
```

Así, cuando la CPU promedio supera el 60 %, ECS agrega instancias; cuando baja,
las reduce.

---

## 7. Configuración centralizada en la nube

En producción, el `config-server` debe leer de un **repositorio Git** en lugar
de archivos locales. Cambia su perfil:

```
SPRING_PROFILES_ACTIVE=git
SPRING_CLOUD_CONFIG_SERVER_GIT_URI=https://github.com/<tu-org>/bancoxyz-config
```

Esto permite versionar y auditar la configuración, y recargarla sin re-desplegar.

---

## 8. Observabilidad y monitoreo

- **Logs:** driver `awslogs` en cada task → **Amazon CloudWatch Logs**.
- **Métricas:** los endpoints `/actuator/metrics` y `/actuator/prometheus`
  (Micrometer) se pueden exportar a CloudWatch o Amazon Managed Prometheus.
- **Salud:** *health checks* de ECS/ALB contra `/actuator/health`.
- **Trazabilidad:** integrable con AWS X-Ray para seguimiento distribuido.

---

## 9. Seguridad en producción

- **HTTPS extremo a extremo:** TLS en el ALB (ACM) y, opcionalmente, entre
  servicios internos.
- **Tokens JWT** de vida corta emitidos por `auth-server` (5–15 min según canal).
- **Secretos** fuera del código, en Secrets Manager.
- **Red:** microservicios y BFF en subredes privadas; solo el Gateway expuesto.
- **IAM** con privilegios mínimos por servicio.

---

## 10. Checklist de despliegue

- [ ] Imágenes publicadas en ECR.
- [ ] RDS (PostgreSQL) y MSK (Kafka) operativos.
- [ ] Secretos cargados en Secrets Manager.
- [ ] `config-server`, `eureka-server` y `auth-server` desplegados y *healthy*.
- [ ] Microservicios, BFF y batch desplegados y registrados en Eureka/Cloud Map.
- [ ] ALB con HTTPS apuntando al `api-gateway`.
- [ ] Autoescalado configurado para los servicios de mayor carga.
- [ ] Logs y métricas visibles en CloudWatch.
