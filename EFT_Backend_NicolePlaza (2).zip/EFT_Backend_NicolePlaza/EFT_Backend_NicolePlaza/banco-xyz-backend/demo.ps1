$ErrorActionPreference = "Continue"

function Titulo($t) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  $t" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
}
function Pausa() { Read-Host ">> Presiona ENTER para continuar" | Out-Null }

# ---------- 1. TOKEN OAuth2 ----------
Titulo "1. Obteniendo token de seguridad (OAuth2)"
Write-Host "El sistema exige un token JWT para operar. Lo pedimos al auth-server..."
$pair  = "web-client:web-secret"
$basic = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
try {
    $tok = Invoke-RestMethod -Method Post -Uri "http://localhost:9001/oauth2/token" `
        -Headers @{ Authorization = "Basic $basic" } `
        -Body @{ grant_type = "client_credentials"; scope = "cuentas.read cuentas.write clientes.read pagos.write" }
    $H = @{ Authorization = "Bearer $($tok.access_token)" }
    Write-Host "Token obtenido correctamente (valido 15 min)." -ForegroundColor Green
} catch {
    Write-Host "No se pudo obtener el token. Revisa que auth-server este arriba (docker compose ps)." -ForegroundColor Red
    return
}
Pausa

# ---------- 2. CREAR CLIENTE ----------
Titulo "2. Creando un cliente (clientes-service)"
$cliente = Invoke-RestMethod -Method Post -Uri "http://localhost:8083/api/clientes" -Headers $H `
    -ContentType "application/json" `
    -Body '{"rut":"12.345.678-9","nombre":"Ana Soto","email":"ana@mail.cl","segmento":"retail"}'
$cliente | Format-List
$clienteId = $cliente.id
Pausa

# ---------- 3. ABRIR CUENTA ----------
Titulo "3. Abriendo una cuenta para el cliente (cuentas-service)"
$cuenta = Invoke-RestMethod -Method Post -Uri "http://localhost:8081/api/cuentas" -Headers $H `
    -ContentType "application/json" `
    -Body (@{ clienteId = $clienteId; tipo = "ahorro" } | ConvertTo-Json)
$cuenta | Format-List
$cuentaId = $cuenta.id
Write-Host ("Cuenta creada con saldo inicial: " + $cuenta.saldo) -ForegroundColor Green
Pausa

# ---------- 4. HACER UN DEPOSITO (pagos-service -> Kafka) ----------
Titulo "4. Procesando un deposito (pagos-service publica evento en Kafka)"
$pago = Invoke-RestMethod -Method Post -Uri "http://localhost:8082/api/pagos" -Headers $H `
    -ContentType "application/json" `
    -Body (@{ cuentaDestinoId = $cuentaId; monto = 50000; tipo = "deposito" } | ConvertTo-Json)
$pago | Format-List
Write-Host "Pago confirmado. El evento viaja por Kafka a cuentas-service..." -ForegroundColor Green
Write-Host "Esperando 4 segundos a que se procese el evento..."
Start-Sleep -Seconds 4
Pausa

# ---------- 5. VER SALDO ACTUALIZADO ----------
Titulo "5. Consultando la cuenta: el saldo se actualizo solo (via Kafka)"
$cuenta2 = Invoke-RestMethod -Method Get -Uri "http://localhost:8081/api/cuentas/$cuentaId" -Headers $H
$cuenta2 | Format-List
Write-Host ("Saldo ahora: " + $cuenta2.saldo + "  (antes era 0)") -ForegroundColor Green
Pausa

# ---------- 6. LANZAR UN PROCESO BATCH ----------
Titulo "6. Ejecutando un proceso Spring Batch (reporte de transacciones diarias)"
$batch = Invoke-RestMethod -Method Post -Uri "http://localhost:8084/api/batch/transacciones-diarias" -Headers $H
$batch | Format-List
Write-Host "Job batch ejecutado. Revisa los logs del batch-service para ver leidos/escritos/omitidos." -ForegroundColor Green
Pausa

# ---------- 7. SEGURIDAD: sin token da 401 ----------
Titulo "7. Prueba de seguridad: sin token, el sistema RECHAZA la peticion"
try {
    Invoke-RestMethod -Method Get -Uri "http://localhost:8081/api/cuentas/$cuentaId" | Out-Null
    Write-Host "(No deberia llegar aqui)" -ForegroundColor Yellow
} catch {
    Write-Host "Correcto: respondio 401 Unauthorized (endpoint protegido por OAuth2)." -ForegroundColor Green
}

Titulo "DEMO COMPLETA"
Write-Host "Resumen mostrado: seguridad OAuth2, microservicios de clientes/cuentas/pagos,"
Write-Host "mensajeria Kafka (saldo actualizado) y procesos Spring Batch." -ForegroundColor Green
