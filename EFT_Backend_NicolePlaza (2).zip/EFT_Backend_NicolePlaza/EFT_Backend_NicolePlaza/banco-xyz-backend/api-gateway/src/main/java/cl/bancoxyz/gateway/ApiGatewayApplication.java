package cl.bancoxyz.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * API Gateway (Spring Cloud Gateway).
 * Punto de entrada unico del sistema. Enruta cada canal a su BFF correspondiente,
 * aplica balanceo de carga (lb://) mediante Eureka y valida el token JWT.
 */
@SpringBootApplication
public class ApiGatewayApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}
