package cl.bancoxyz.bffcajero.controller;

import cl.bancoxyz.bffcajero.client.CuentasClient;
import cl.bancoxyz.bffcajero.client.PagosClient;
import cl.bancoxyz.bffcajero.dto.*;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

/**
 * Operaciones criticas de cajero. Consulta de saldo y retiro con validacion de
 * fondos y estado de la cuenta. Toda la logica sensible se mantiene en el
 * backend; el cajero recibe respuestas minimas.
 */
@RestController
@RequestMapping("/api/cajero")
public class CajeroController {

    private final CuentasClient cuentasClient;
    private final PagosClient pagosClient;

    public CajeroController(CuentasClient cuentasClient, PagosClient pagosClient) {
        this.cuentasClient = cuentasClient;
        this.pagosClient = pagosClient;
    }

    @GetMapping("/saldo/{cuentaId}")
    @CircuitBreaker(name = "backendServices", fallbackMethod = "fallbackSaldo")
    public SaldoDTO consultarSaldo(@PathVariable Long cuentaId) {
        CuentaDTO c = cuentasClient.obtener(cuentaId);
        return new SaldoDTO(c.id(), c.saldo(), c.estado());
    }

    @PostMapping("/retiro")
    @CircuitBreaker(name = "backendServices", fallbackMethod = "fallbackRetiro")
    public PagoDTO retirar(@Valid @RequestBody RetiroRequest req) {
        CuentaDTO cuenta = cuentasClient.obtener(req.cuentaId());
        if (!"ACTIVA".equals(cuenta.estado())) {
            throw new IllegalStateException("Cuenta no activa");
        }
        if (cuenta.saldo().compareTo(req.monto()) < 0) {
            throw new IllegalStateException("Fondos insuficientes");
        }
        PagoRequest pago = new PagoRequest(req.cuentaId(), null, req.monto(), "retiro");
        return pagosClient.procesar(pago);
    }

    @SuppressWarnings("unused")
    private SaldoDTO fallbackSaldo(Long cuentaId, Throwable t) {
        throw new IllegalStateException("Servicio no disponible, intente mas tarde");
    }

    @SuppressWarnings("unused")
    private PagoDTO fallbackRetiro(RetiroRequest req, Throwable t) {
        throw new IllegalStateException("No fue posible completar el retiro, intente mas tarde");
    }
}
