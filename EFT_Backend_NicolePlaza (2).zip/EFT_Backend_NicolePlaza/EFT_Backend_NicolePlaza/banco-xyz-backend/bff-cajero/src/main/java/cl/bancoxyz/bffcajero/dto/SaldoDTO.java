package cl.bancoxyz.bffcajero.dto;

import java.math.BigDecimal;

/** Respuesta minima para el cajero: solo numero de cuenta y saldo. */
public record SaldoDTO(Long cuentaId, BigDecimal saldo, String estado) {
}
