package cl.bancoxyz.bffcajero.dto;

import java.math.BigDecimal;

public record CuentaDTO(Long id, Long clienteId, String tipo, BigDecimal saldo, String estado) {
}
