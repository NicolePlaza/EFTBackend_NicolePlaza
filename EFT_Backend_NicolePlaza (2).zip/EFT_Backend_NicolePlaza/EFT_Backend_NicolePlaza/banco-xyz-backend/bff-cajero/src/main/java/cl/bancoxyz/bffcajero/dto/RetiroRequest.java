package cl.bancoxyz.bffcajero.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

public record RetiroRequest(@NotNull Long cuentaId, @NotNull @Positive BigDecimal monto) {
}
