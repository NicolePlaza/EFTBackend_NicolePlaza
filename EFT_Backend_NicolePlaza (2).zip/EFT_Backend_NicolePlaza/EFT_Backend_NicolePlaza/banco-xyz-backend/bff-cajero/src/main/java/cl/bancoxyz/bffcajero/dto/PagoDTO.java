package cl.bancoxyz.bffcajero.dto;

import java.math.BigDecimal;

public record PagoDTO(Long id, Long cuentaOrigenId, BigDecimal monto, String tipo, String estado) {
}
