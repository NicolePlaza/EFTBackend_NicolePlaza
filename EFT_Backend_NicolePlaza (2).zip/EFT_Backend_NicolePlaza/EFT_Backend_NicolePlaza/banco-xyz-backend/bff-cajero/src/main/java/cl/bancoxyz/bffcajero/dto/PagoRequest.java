package cl.bancoxyz.bffcajero.dto;

import java.math.BigDecimal;

public record PagoRequest(Long cuentaOrigenId, Long cuentaDestinoId, BigDecimal monto, String tipo) {
}
