package cl.bancoxyz.bffcajero.client;

import cl.bancoxyz.bffcajero.dto.PagoRequest;
import cl.bancoxyz.bffcajero.dto.PagoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "pagos-service")
public interface PagosClient {
    @PostMapping("/api/pagos")
    PagoDTO procesar(@RequestBody PagoRequest req);
}
