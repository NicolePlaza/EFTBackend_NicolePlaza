package cl.bancoxyz.bffcajero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * BFF Cajeros Automaticos: interfaz segura y eficiente para operaciones
 * criticas (consulta de saldo y retiro). Expone solo lo imprescindible y
 * aplica validaciones estrictas.
 */
@SpringBootApplication
@EnableFeignClients
public class BffCajeroApplication {
    public static void main(String[] args) {
        SpringApplication.run(BffCajeroApplication.class, args);
    }
}
