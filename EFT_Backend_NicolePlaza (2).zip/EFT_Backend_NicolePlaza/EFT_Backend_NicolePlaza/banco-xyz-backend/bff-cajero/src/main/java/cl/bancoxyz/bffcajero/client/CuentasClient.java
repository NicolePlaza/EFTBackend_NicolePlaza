package cl.bancoxyz.bffcajero.client;

import cl.bancoxyz.bffcajero.dto.CuentaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "cuentas-service")
public interface CuentasClient {
    @GetMapping("/api/cuentas/{id}")
    CuentaDTO obtener(@PathVariable("id") Long id);
}
