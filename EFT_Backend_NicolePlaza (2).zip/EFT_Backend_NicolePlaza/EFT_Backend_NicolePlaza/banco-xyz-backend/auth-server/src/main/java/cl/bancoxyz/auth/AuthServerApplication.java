package cl.bancoxyz.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Servidor de Autorizacion OAuth2 (Spring Authorization Server).
 * Centraliza la seguridad distribuida: emite tokens JWT firmados que luego
 * validan el Gateway y cada microservicio (resource servers). Cada canal
 * (web, movil, cajero) dispone de su propio client_id y scopes.
 */
@SpringBootApplication
public class AuthServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(AuthServerApplication.class, args);
    }
}
