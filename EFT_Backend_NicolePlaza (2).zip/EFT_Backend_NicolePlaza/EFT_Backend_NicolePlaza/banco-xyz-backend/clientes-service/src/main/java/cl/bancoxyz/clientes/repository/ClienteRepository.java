package cl.bancoxyz.clientes.repository;

import cl.bancoxyz.clientes.domain.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
}
