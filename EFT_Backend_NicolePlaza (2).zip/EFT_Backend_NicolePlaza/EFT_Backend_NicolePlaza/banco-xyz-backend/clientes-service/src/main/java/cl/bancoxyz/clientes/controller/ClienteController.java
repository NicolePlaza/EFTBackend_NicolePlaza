package cl.bancoxyz.clientes.controller;

import cl.bancoxyz.clientes.domain.Cliente;
import cl.bancoxyz.clientes.dto.ClienteRequest;
import cl.bancoxyz.clientes.service.ClienteService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/clientes")
public class ClienteController {

    private final ClienteService service;

    public ClienteController(ClienteService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SCOPE_clientes.read')")
    public Cliente crear(@Valid @RequestBody ClienteRequest r) {
        return service.crear(r);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('SCOPE_clientes.read')")
    public Cliente obtener(@PathVariable Long id) {
        return service.obtener(id);
    }

    @GetMapping
    @PreAuthorize("hasAuthority('SCOPE_clientes.read')")
    public List<Cliente> listar() {
        return service.listar();
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('SCOPE_clientes.read')")
    public Cliente actualizar(@PathVariable Long id, @Valid @RequestBody ClienteRequest r) {
        return service.actualizar(id, r);
    }
}
