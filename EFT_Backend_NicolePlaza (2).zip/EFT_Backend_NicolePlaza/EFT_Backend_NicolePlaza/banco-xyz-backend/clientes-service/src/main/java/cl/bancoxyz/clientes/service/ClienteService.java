package cl.bancoxyz.clientes.service;

import cl.bancoxyz.clientes.domain.Cliente;
import cl.bancoxyz.clientes.dto.ClienteRequest;
import cl.bancoxyz.clientes.repository.ClienteRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class ClienteService {

    private final ClienteRepository repo;

    public ClienteService(ClienteRepository repo) {
        this.repo = repo;
    }

    public Cliente crear(ClienteRequest r) {
        Cliente c = new Cliente();
        aplicar(c, r);
        return repo.save(c);
    }

    public Cliente obtener(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Cliente no encontrado: " + id));
    }

    public List<Cliente> listar() {
        return repo.findAll();
    }

    public Cliente actualizar(Long id, ClienteRequest r) {
        Cliente c = obtener(id);
        aplicar(c, r);
        return repo.save(c);
    }

    private void aplicar(Cliente c, ClienteRequest r) {
        c.setRut(r.rut());
        c.setNombre(r.nombre());
        c.setEmail(r.email());
        c.setTelefono(r.telefono());
        c.setSegmento(r.segmento());
    }
}
