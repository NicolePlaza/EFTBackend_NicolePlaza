package cl.bancoxyz.clientes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Microservicio de Gestion de Clientes: datos personales y perfiles. */
@SpringBootApplication
public class ClientesServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(ClientesServiceApplication.class, args);
    }
}
