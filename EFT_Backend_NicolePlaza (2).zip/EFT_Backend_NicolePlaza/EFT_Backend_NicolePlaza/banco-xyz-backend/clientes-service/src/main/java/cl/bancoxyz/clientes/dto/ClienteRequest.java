package cl.bancoxyz.clientes.dto;

import jakarta.validation.constraints.NotBlank;

public record ClienteRequest(
        @NotBlank String rut,
        @NotBlank String nombre,
        String email,
        String telefono,
        String segmento) {
}
