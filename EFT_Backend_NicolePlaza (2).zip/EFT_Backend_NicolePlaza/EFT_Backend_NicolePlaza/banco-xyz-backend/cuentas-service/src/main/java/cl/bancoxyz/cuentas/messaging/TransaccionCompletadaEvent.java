package cl.bancoxyz.cuentas.messaging;

import java.math.BigDecimal;

/** Evento recibido cuando el pagos-service completa una transaccion. */
public record TransaccionCompletadaEvent(
        String transaccionId,
        Long cuentaOrigenId,
        Long cuentaDestinoId,
        BigDecimal monto,
        String tipo) {
}
