package cl.bancoxyz.cuentas.service;

import cl.bancoxyz.cuentas.domain.Cuenta;
import cl.bancoxyz.cuentas.domain.EstadoCuenta;
import cl.bancoxyz.cuentas.dto.CrearCuentaRequest;
import cl.bancoxyz.cuentas.repository.CuentaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;

/** Logica de negocio de la gestion de cuentas. */
@Service
public class CuentaService {

    private final CuentaRepository repo;

    public CuentaService(CuentaRepository repo) {
        this.repo = repo;
    }

    @Transactional
    public Cuenta abrir(CrearCuentaRequest req) {
        Cuenta c = new Cuenta();
        c.setClienteId(req.clienteId());
        c.setTipo(req.tipo());
        c.setEstado(EstadoCuenta.ACTIVA);
        return repo.save(c);
    }

    public Cuenta obtener(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Cuenta no encontrada: " + id));
    }

    public List<Cuenta> porCliente(Long clienteId) {
        return repo.findByClienteId(clienteId);
    }

    @Transactional
    public Cuenta cerrar(Long id) {
        Cuenta c = obtener(id);
        if (c.getSaldo().compareTo(BigDecimal.ZERO) != 0) {
            throw new IllegalStateException("No se puede cerrar una cuenta con saldo distinto de cero");
        }
        c.setEstado(EstadoCuenta.CERRADA);
        c.setFechaCierre(LocalDateTime.now());
        return repo.save(c);
    }

    /** Mantenimiento: ajuste de saldo invocado por el consumidor de eventos. */
    @Transactional
    public void aplicarMovimiento(Long cuentaId, BigDecimal delta) {
        Cuenta c = obtener(cuentaId);
        c.setSaldo(c.getSaldo().add(delta));
        repo.save(c);
    }
}
