package cl.bancoxyz.cuentas.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record CrearCuentaRequest(
        @NotNull Long clienteId,
        @NotBlank String tipo) {
}
