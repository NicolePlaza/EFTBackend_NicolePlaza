package cl.bancoxyz.cuentas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Microservicio de Gestion de Cuentas: apertura, cierre y mantenimiento de
 * cuentas bancarias. Consume eventos Kafka de transacciones completadas para
 * actualizar los saldos de forma asincrona.
 */
@SpringBootApplication
public class CuentasServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(CuentasServiceApplication.class, args);
    }
}
