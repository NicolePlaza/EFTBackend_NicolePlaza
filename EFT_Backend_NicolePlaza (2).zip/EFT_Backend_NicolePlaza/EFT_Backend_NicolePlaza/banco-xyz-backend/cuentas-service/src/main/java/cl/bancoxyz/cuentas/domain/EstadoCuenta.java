package cl.bancoxyz.cuentas.domain;

public enum EstadoCuenta {
    ACTIVA, BLOQUEADA, CERRADA
}
