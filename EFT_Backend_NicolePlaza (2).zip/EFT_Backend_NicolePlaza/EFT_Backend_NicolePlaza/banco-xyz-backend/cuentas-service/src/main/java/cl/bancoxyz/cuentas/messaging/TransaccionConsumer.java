package cl.bancoxyz.cuentas.messaging;

import cl.bancoxyz.cuentas.service.CuentaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Consumidor Kafka del topico "transacciones-completadas". Procesa eventos en
 * tiempo real para actualizar los saldos de las cuentas involucradas,
 * garantizando consistencia eventual en el entorno distribuido.
 */
@Component
public class TransaccionConsumer {

    private static final Logger log = LoggerFactory.getLogger(TransaccionConsumer.class);
    private final CuentaService cuentaService;

    public TransaccionConsumer(CuentaService cuentaService) {
        this.cuentaService = cuentaService;
    }

    @KafkaListener(topics = "transacciones-completadas", groupId = "cuentas-service")
    public void onTransaccion(TransaccionCompletadaEvent evento) {
        log.info("Evento recibido: {}", evento);
        if (evento.cuentaOrigenId() != null) {
            cuentaService.aplicarMovimiento(evento.cuentaOrigenId(), evento.monto().negate());
        }
        if (evento.cuentaDestinoId() != null) {
            cuentaService.aplicarMovimiento(evento.cuentaDestinoId(), evento.monto());
        }
    }
}
