package cl.bancoxyz.cuentas.controller;

import cl.bancoxyz.cuentas.domain.Cuenta;
import cl.bancoxyz.cuentas.dto.CrearCuentaRequest;
import cl.bancoxyz.cuentas.service.CuentaService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cuentas")
public class CuentaController {

    private final CuentaService service;

    public CuentaController(CuentaService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("hasAuthority('SCOPE_cuentas.write')")
    public ResponseEntity<Cuenta> abrir(@Valid @RequestBody CrearCuentaRequest req) {
        return ResponseEntity.ok(service.abrir(req));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('SCOPE_cuentas.read')")
    public Cuenta obtener(@PathVariable Long id) {
        return service.obtener(id);
    }

    @GetMapping
    @PreAuthorize("hasAuthority('SCOPE_cuentas.read')")
    public List<Cuenta> porCliente(@RequestParam Long clienteId) {
        return service.porCliente(clienteId);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('SCOPE_cuentas.write')")
    public Cuenta cerrar(@PathVariable Long id) {
        return service.cerrar(id);
    }
}
